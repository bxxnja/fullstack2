// ===========================
// 📦 Datos de Productos
// ===========================
const panes = [
    { id: 1, name: "Pan de Trigo", description: "Pan fresco de trigo con textura suave", precio: 2.50, image: "https://images.unsplash.com/photo-1509440159596-0249088772ff?w=400", stock: 25 },
    { id: 2, name: "Pan Integral", description: "Pan integral rico en fibra", precio: 3.00, image: "https://images.unsplash.com/photo-1549931319-a545dcf3bc73?w=400", stock: 15 },
    { id: 3, name: "Croissant", description: "Delicioso croissant francés", precio: 1.80, image: "https://images.unsplash.com/photo-1555507036-ab1f4038808a?w=400", stock: 30 },
    { id: 4, name: "Pan de Ajo", description: "Pan artesanal con ajo fresco", precio: 3.50, image: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=400", stock: 12 }
];

// ===========================
// 🛒 Funciones del Carrito
// ===========================
function calcularTotalCarrito() {
    const carrito = JSON.parse(localStorage.getItem("carrito")) || [];
    const total = carrito.reduce((sum, item) => {
        const precio = parseFloat(item.price) || 0;
        const cantidad = parseInt(item.cantidad) || 0;
        return sum + (precio * cantidad);
    }, 0);
    document.getElementById("cart-count").textContent = total.toFixed(2);
}

function getCarrito() {
    return JSON.parse(localStorage.getItem("panaderia-carrito")) || [];
}

function guardarCarrito(carrito) {
    localStorage.setItem("panaderia-carrito", JSON.stringify(carrito));
    actualizarContadorCarrito();
}

function addToCart(productId) {
    let carrito = JSON.parse(localStorage.getItem("panaderia-carrito")) || [];
    const product = panes.find(p => p.id === productId);

    if (!product) return;

    const existingItem = carrito.find(item => item.id === productId);
    if (existingItem) {
        if (existingItem.cantidad < product.stock) {
            existingItem.cantidad++;
        } else {
            alert("No hay suficiente stock disponible");
            return;
        }
    } else {
        carrito.push({
            id: product.id,
            name: product.name,
            precio: product.precio,
            image: product.image,
            cantidad: 1,
            stock: product.stock
        });
    }

    localStorage.setItem("panaderia-carrito", JSON.stringify(carrito));
    actualizarContadorCarrito();
    alert(`${product.name} añadido al carrito`);
}


function actualizarContadorCarrito() {
    const contador = document.querySelectorAll("#cart-count");
    if (contador.length > 0) {
        const carrito = getCarrito();
        contador.forEach(c => c.textContent = carrito.reduce((sum, item) => sum + item.cantidad, 0));
    }
}

function cargarCarrito() {
    const carrito = getCarrito();
    const container = document.getElementById("cart-content");

    if (!container) return;

    if (!carrito.length) {
        container.innerHTML = `
            <div class="empty-cart">
                <h2>Tu carrito está vacío</h2>
                <a href="../index.html">Seguir Comprando</a>
            </div>
        `;
        return;
    }

    let total = 0;
    container.innerHTML = carrito.map(item => {
        total += item.precio * item.cantidad;
        return `
            <div class="cart-item">
                <img src="${item.image}" alt="${item.name}" class="item-image">
                <div class="item-info">
                    <h3>${item.name}</h3>
                    <p>$${item.precio.toFixed(2)}</p>
                </div>
                <div class="quantity-controls">
                    <button onclick="cambiarCantidad(${item.id}, -1)">-</button>
                    <input type="number" value="${item.cantidad}" min="1" max="${item.stock}" onchange="actualizarCantidad(${item.id}, this.value)">
                    <button onclick="cambiarCantidad(${item.id}, 1)">+</button>
                </div>
                <span class="item-total">Total: $${(item.precio * item.cantidad).toFixed(2)}</span>
                <button class="remove-btn" onclick="eliminarItem(${item.id})">Eliminar</button>
            </div>
        `;
    }).join("");

    container.innerHTML += `
        <div class="cart-summary">
            <h3>Total: $${total.toFixed(2)}</h3>
            <button onclick="procederPago()">Proceder al Pago</button>
        </div>
    `;
}

function cambiarCantidad(id, delta) {
    let carrito = getCarrito();
    const item = carrito.find(p => p.id === id);
    if (!item) return;

    const nuevaCantidad = item.cantidad + delta;
    if (nuevaCantidad < 1) { eliminarItem(id); return; }
    if (nuevaCantidad > item.stock) { alert("No hay suficiente stock disponible"); return; }

    item.cantidad = nuevaCantidad;
    guardarCarrito(carrito);
    cargarCarrito();
}

function actualizarCantidad(id, cantidad) {
    let carrito = getCarrito();
    const item = carrito.find(p => p.id === id);
    if (!item) return;

    const cant = parseInt(cantidad);
    if (cant < 1) { eliminarItem(id); return; }
    if (cant > item.stock) { alert("No hay suficiente stock disponible"); return; }

    item.cantidad = cant;
    guardarCarrito(carrito);
    cargarCarrito();
}

function eliminarItem(id) {
    let carrito = getCarrito();
    carrito = carrito.filter(item => item.id !== id);
    guardarCarrito(carrito);
    cargarCarrito();
}

function procederPago() {
    alert("¡Gracias por tu compra!");
    localStorage.removeItem("panaderia-carrito");
    actualizarContadorCarrito();
    cargarCarrito();
}
function renderProducts() {
    const container = document.getElementById("products-container");
    if (!container) return;

    container.innerHTML = panes.map(pan => `
        <div class="product-card">
            <img src="${pan.image}" alt="${pan.name}">
            <h3>${pan.name}</h3>
            <p>${pan.description}</p>
            <p>$${pan.precio.toFixed(2)}</p>
            <button class="btn-add-cart" onclick="addToCart(${pan.id})">
                🛒 Añadir al carrito
            </button>
        </div>
    `).join("");
}


document.addEventListener("DOMContentLoaded", () => {
    renderProducts();
    cargarCarrito();
    actualizarContadorCarrito();
});
