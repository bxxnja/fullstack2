
// Guardar productos iniciales en LocalStorage si no existen
if (!localStorage.getItem("panaderia-panes")) {
    localStorage.setItem("panaderia-panes", JSON.stringify(productosIniciales));
}



class ProductManager {
    constructor() {
        this.products = this.loadProducts();
        this.currentProductId = null;
        this.init();
    }
    
    init() {
        this.renderProducts();
        this.updateStats();
        this.bindEvents();
    }
    
    loadProducts() {
        const savedProducts = localStorage.getItem('panaderia-panes');
        if (savedProducts) {
            try {
                return JSON.parse(savedProducts);
            } catch (e) {
                console.error('Error al cargar productos:', e);
            }
        }
        return [];
    }
    
    saveProducts() {
        try {
            localStorage.setItem('panaderia-panes', JSON.stringify(this.products));
            return true;
        } catch (e) {
            console.error('Error al guardar productos:', e);
            return false;
        }
    }
    
    bindEvents() {
        // Botón agregar producto
        const addBtn = document.getElementById('add-product-btn');
        if (addBtn) {
            addBtn.addEventListener('click', () => this.showModal());
        }
        
        // Modal
        const modal = document.getElementById('product-modal');
        const closeBtn = document.querySelector('.close');
        const cancelBtn = document.getElementById('cancel-btn');
        
        if (closeBtn) closeBtn.addEventListener('click', () => this.hideModal());
        if (cancelBtn) cancelBtn.addEventListener('click', () => this.hideModal());
        
        if (modal) {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    this.hideModal();
                }
            });
        }
        
        // Formulario
        const form = document.getElementById('product-form');
        if (form) {
            form.addEventListener('submit', (e) => this.handleSubmit(e));
        }
        
        // Búsqueda
        const searchInput = document.getElementById('search-products');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => this.searchProducts(e.target.value));
        }

        // Delegación de eventos para eliminar productos
        const tbody = document.getElementById('products-table-body');
        if (tbody) {
            tbody.addEventListener('click', (e) => {
                if (e.target.classList.contains('btn-danger')) {
                    const row = e.target.closest('tr');
                    const id = row.dataset.id;
                    this.deleteProduct(id);
                }
                if (e.target.classList.contains('btn-warning')) {
                    const row = e.target.closest('tr');
                    const id = row.dataset.id;
                    const product = this.products.find(p => p.id === id);
                    if (product) this.showModal(product);
                }
                if (e.target.classList.contains('btn-secondary') || e.target.classList.contains('btn-primary')) {
                    const row = e.target.closest('tr');
                    const id = row.dataset.id;
                    this.toggleProductStatus(id);
                }
            });
        }
    }
    
    showModal(product = null) {
        const modal = document.getElementById('product-modal');
        const modalTitle = document.getElementById('modal-title');
        const form = document.getElementById('product-form');
        
        if (product) {
            this.currentProductId = product.id;
            modalTitle.textContent = 'Editar Pan';
            this.fillForm(product);
        } else {
            this.currentProductId = null;
            modalTitle.textContent = 'Agregar Nuevo Pan';
            form.reset();
        }
        
        this.clearErrors();
        modal.style.display = 'block';
        document.body.style.overflow = 'hidden';
    }
    
    hideModal() {
        const modal = document.getElementById('product-modal');
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
        this.currentProductId = null;
    }
    
    fillForm(product) {
        document.getElementById('product-name').value = product.name;
        document.getElementById('product-description').value = product.description;
        document.getElementById('product-price').value = product.price;
        document.getElementById('product-image').value = product.image;
        document.getElementById('product-category').value = product.category;
        document.getElementById('product-stock').value = product.stock;
        document.getElementById('product-active').checked = product.active;
    }
    
    clearErrors() {
        const errorElements = document.querySelectorAll('.error-message');
        errorElements.forEach(el => el.textContent = '');
    }
    
    validateForm(formData) {
        const errors = {};
        
        if (!formData.name.trim()) errors.name = 'El nombre es requerido';
        else if (formData.name.trim().length < 2) errors.name = 'El nombre debe tener al menos 2 caracteres';
        
        if (!formData.description.trim()) errors.description = 'La descripción es requerida';
        else if (formData.description.trim().length < 10) errors.description = 'La descripción debe tener al menos 10 caracteres';
        
        const price = parseFloat(formData.price);
        if (!formData.price || isNaN(price)) errors.price = 'El precio es requerido';
        else if (price <= 0) errors.price = 'El precio debe ser mayor a 0';
        else if (price > 1000) errors.price = 'El precio no puede ser mayor a $1000';
        
        if (!formData.image.trim()) errors.image = 'La URL de imagen es requerida';
        else if (!this.isValidUrl(formData.image)) errors.image = 'La URL de imagen no es válida';
        
        if (!formData.category) errors.category = 'La categoría es requerida';
        
        const stock = parseInt(formData.stock);
        if (!formData.stock || isNaN(stock)) errors.stock = 'El stock es requerido';
        else if (stock < 0) errors.stock = 'El stock no puede ser negativo';
        else if (stock > 1000) errors.stock = 'El stock no puede ser mayor a 1000';
        
        return errors;
    }
    
    isValidUrl(string) {
        try {
            new URL(string);
            return true;
        } catch (_) {
            return false;
        }
    }
    
    showErrors(errors) {
        this.clearErrors();
        Object.keys(errors).forEach(field => {
            const errorElement = document.getElementById(`${field}-error`);
            if (errorElement) errorElement.textContent = errors[field];
        });
    }
    
    handleSubmit(e) {
        e.preventDefault();
        const formData = new FormData(e.target);
        const data = Object.fromEntries(formData);
        data.active = document.getElementById('product-active').checked;
        
        const errors = this.validateForm(data);
        if (Object.keys(errors).length > 0) {
            this.showErrors(errors);
            return;
        }
        
        const productData = {
            name: data.name.trim(),
            description: data.description.trim(),
            price: parseFloat(data.price),
            image: data.image.trim(),
            category: data.category,
            stock: parseInt(data.stock),
            active: data.active
        };
        
        if (this.currentProductId) {
            this.updateProduct(this.currentProductId, productData);
        } else {
            this.createProduct(productData);
        }
    }
    
    createProduct(productData) {
        const newProduct = {
            id: this.generateId(),
            ...productData,
            createdAt: new Date().toISOString()
        };
        
        this.products.push(newProduct);
        if (this.saveProducts()) {
            this.renderProducts();
            this.updateStats();
            this.hideModal();
            this.showMessage('Pan creado exitosamente', 'success');
        } else {
            this.showMessage('Error al guardar el pan', 'error');
        }
    }
    
    updateProduct(id, productData) {
        const index = this.products.findIndex(p => p.id === id);
        if (index !== -1) {
            this.products[index] = {
                ...this.products[index],
                ...productData,
                updatedAt: new Date().toISOString()
            };
            
            if (this.saveProducts()) {
                this.renderProducts();
                this.updateStats();
                this.hideModal();
                this.showMessage('Pan actualizado exitosamente', 'success');
            } else {
                this.showMessage('Error al actualizar el pan', 'error');
            }
        }
    }
    
    deleteProduct(id) {
        if (confirm('¿Estás seguro de que quieres eliminar este pan?')) {
            this.products = this.products.filter(p => p.id !== id);
            if (this.saveProducts()) {
                this.renderProducts();
                this.updateStats();
                this.showMessage('Pan eliminado exitosamente', 'success');
            } else {
                this.showMessage('Error al eliminar el pan', 'error');
            }
        }
    }
    
    toggleProductStatus(id) {
        const product = this.products.find(p => p.id === id);
        if (product) {
            product.active = !product.active;
            product.updatedAt = new Date().toISOString();
            if (this.saveProducts()) {
                this.renderProducts();
                this.updateStats();
                this.showMessage(`Pan ${product.active ? 'activado' : 'desactivado'} exitosamente`, 'success');
            } else {
                this.showMessage('Error al cambiar el estado del pan', 'error');
            }
        }
    }
    
    searchProducts(query) {
        const filteredProducts = this.products.filter(product => 
            product.name.toLowerCase().includes(query.toLowerCase()) ||
            product.description.toLowerCase().includes(query.toLowerCase()) ||
            product.category.toLowerCase().includes(query.toLowerCase())
        );
        
        this.renderProducts(filteredProducts);
    }
    
    generateId() {
        return (Date.now() + Math.random().toString(36).substr(2, 9)).toString();
    }
    
    renderProducts(products = this.products) {
        const tbody = document.getElementById('products-table-body');
        if (!tbody) return;
        
        if (products.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="8" class="empty-state">
                        <h3>No hay panes registrados</h3>
                        <p>Haz clic en "Agregar Nuevo Pan" para comenzar</p>
                    </td>
                </tr>
            `;
            return;
        }
        
        tbody.innerHTML = products.map(product => `
            <tr data-id="${product.id}">
                <td><img src="${product.image}" alt="${product.name}" 
                         onerror="this.src='https://via.placeholder.com/60x60/8B4513/FFFFFF?text=No+Img'"></td>
                <td class="product-name-cell">${product.name}</td>
                <td class="product-description-cell" title="${product.description}">${product.description}</td>
                <td class="product-price-cell">$${product.price.toFixed(2)}</td>
                <td class="product-category-cell">${this.getCategoryName(product.category)}</td>
                <td class="product-stock-cell">${product.stock}</td>
                <td><span class="product-status-cell status-${product.active ? 'active' : 'inactive'}">${product.active ? 'Activo' : 'Inactivo'}</span></td>
                <td>
                    <div class="table-actions">
                        <button class="btn btn-warning">✏️ Editar</button>
                        <button class="btn ${product.active ? 'btn-secondary' : 'btn-primary'}">
                            ${product.active ? '⏸️ Desactivar' : '▶️ Activar'}
                        </button>
                        <button class="btn btn-danger">🗑️ Eliminar</button>
                    </div>
                </td>
            </tr>
        `).join('');
    }
    
    getCategoryName(category) {
        const categories = {
            'panes-basicos': 'Panes Básicos',
            'panes-especiales': 'Panes Especiales',
            'dulces': 'Dulces',
            'integrales': 'Integrales'
        };
        return categories[category] || category;
    }
    
    updateStats() {
        const totalPanes = this.products.length;
        const panesActivos = this.products.filter(p => p.active).length;
        const precioPromedio = this.products.length > 0 
            ? this.products.reduce((sum, p) => sum + p.price, 0) / this.products.length 
            : 0;
        
        document.getElementById('total-panes').textContent = totalPanes;
        document.getElementById('panes-activos').textContent = panesActivos;
        document.getElementById('precio-promedio').textContent = `$${precioPromedio.toFixed(2)}`;
    }
    
    showMessage(message, type = 'success') {
        const existingMessages = document.querySelectorAll('.message');
        existingMessages.forEach(msg => msg.remove());
        
        const messageDiv = document.createElement('div');
        messageDiv.className = `message message-${type}`;
        messageDiv.textContent = message;
        
        const adminProducts = document.querySelector('.admin-products');
        if (adminProducts) {
            adminProducts.insertBefore(messageDiv, adminProducts.firstChild);
            setTimeout(() => messageDiv.remove(), 5000);
        }
    }
}

document.addEventListener('DOMContentLoaded', function() {
    if (document.getElementById('product-modal')) {
        window.productManager = new ProductManager();
    }
});
// ===========================
// 👥 Clase para manejar CRUD de usuarios
// ===========================
class UserManager {
    constructor() {
        this.users = this.loadUsers();
        this.currentUserId = null;
        this.init();
    }

    init() {
        this.renderUsers();
        this.bindEvents();
    }

    loadUsers() {
        const savedUsers = localStorage.getItem('panaderia-usuarios');
        if (savedUsers) {
            try {
                return JSON.parse(savedUsers);
            } catch (e) {
                console.error('Error al cargar usuarios:', e);
            }
        }
        return [];
    }

    saveUsers() {
        try {
            localStorage.setItem('panaderia-usuarios', JSON.stringify(this.users));
            return true;
        } catch (e) {
            console.error('Error al guardar usuarios:', e);
            return false;
        }
    }

    bindEvents() {
        const addBtn = document.getElementById('add-user-btn');
        if (addBtn) {
            addBtn.addEventListener('click', () => this.showModal());
        }

        const form = document.getElementById('user-form');
        if (form) {
            form.addEventListener('submit', (e) => this.handleSubmit(e));
        }

        const tbody = document.getElementById('users-table-body');
        if (tbody) {
            tbody.addEventListener('click', (e) => {
                const row = e.target.closest('tr');
                if (!row) return;
                const id = row.dataset.id;

                if (e.target.classList.contains('btn-danger')) {
                    this.deleteUser(id);
                }
                if (e.target.classList.contains('btn-warning')) {
                    const user = this.users.find(u => u.id === id);
                    if (user) this.showModal(user);
                }
            });
        }
    }

    showModal(user = null) {
        const modal = document.getElementById('user-modal');
        const modalTitle = document.getElementById('user-modal-title');
        const form = document.getElementById('user-form');

        if (user) {
            this.currentUserId = user.id;
            modalTitle.textContent = 'Editar Usuario';
            this.fillForm(user);
        } else {
            this.currentUserId = null;
            modalTitle.textContent = 'Agregar Usuario';
            form.reset();
        }

        modal.style.display = 'block';
        document.body.style.overflow = 'hidden';
    }

    hideModal() {
        const modal = document.getElementById('user-modal');
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
        this.currentUserId = null;
    }

    fillForm(user) {
        document.getElementById('user-name').value = user.name;
        document.getElementById('user-email').value = user.email;
        document.getElementById('user-role').value = user.role;
    }

    handleSubmit(e) {
        e.preventDefault();
        const formData = new FormData(e.target);
        const data = Object.fromEntries(formData);

        if (!data.name.trim() || !data.email.trim()) {
            alert("Todos los campos son obligatorios");
            return;
        }

        const userData = {
            name: data.name.trim(),
            email: data.email.trim(),
            role: data.role
        };

        if (this.currentUserId) {
            this.updateUser(this.currentUserId, userData);
        } else {
            this.createUser(userData);
        }
    }

    createUser(userData) {
        const newUser = {
            id: Date.now().toString(),
            ...userData,
            createdAt: new Date().toISOString()
        };

        this.users.push(newUser);
        if (this.saveUsers()) {
            this.renderUsers();
            this.hideModal();
            alert("Usuario creado exitosamente");
        }
    }

    updateUser(id, userData) {
        const index = this.users.findIndex(u => u.id === id);
        if (index !== -1) {
            this.users[index] = {
                ...this.users[index],
                ...userData,
                updatedAt: new Date().toISOString()
            };

            if (this.saveUsers()) {
                this.renderUsers();
                this.hideModal();
                alert("Usuario actualizado exitosamente");
            }
        }
    }

    deleteUser(id) {
        if (confirm("¿Estás seguro de eliminar este usuario?")) {
            this.users = this.users.filter(u => u.id !== id);
            if (this.saveUsers()) {
                this.renderUsers();
                alert("Usuario eliminado exitosamente");
            }
        }
    }

    renderUsers(users = this.users) {
        const tbody = document.getElementById('users-table-body');
        if (!tbody) return;

        if (users.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="4" class="empty-state">
                        <p>No hay usuarios registrados</p>
                    </td>
                </tr>
            `;
            return;
        }

        tbody.innerHTML = users.map(user => `
            <tr data-id="${user.id}">
                <td>${user.name}</td>
                <td>${user.email}</td>
                <td>${user.role}</td>
                <td>
                    <button class="btn btn-warning">✏️ Editar</button>
                    <button class="btn btn-danger">🗑️ Eliminar</button>
                </td>
            </tr>
        `).join('');
    }
}
document.addEventListener('DOMContentLoaded', function () {
    if (document.getElementById('product-modal')) {
        window.productManager = new ProductManager();
    }

    if (document.getElementById('user-modal')) {
        window.userManager = new UserManager();
    }
});
