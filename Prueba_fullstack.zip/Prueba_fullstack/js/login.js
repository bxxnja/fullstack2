document.getElementById('loginForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value.trim();
    let valid = true;

    document.querySelectorAll('.error-message').forEach(el => el.style.display = 'none');

    if (!email) { showError('emailError', 'El correo es requerido'); valid = false; }
    if (!password) { showError('passwordError', 'La contraseña es requerida'); valid = false; }
    if (!valid) return;

    const usuarios = JSON.parse(localStorage.getItem('usuarios')) || [];

    const usuario = usuarios.find(u => u.email === email && u.password === password);

    if (usuario) {
        localStorage.setItem('usuarioLogueado', JSON.stringify(usuario));
        alert(`¡Bienvenido ${usuario.nombre}!`);
        window.location.href = '../index.html';
    } else {
        showError('passwordError', 'Correo o contraseña incorrectos');
    }
});

function showError(id, message) {
    const el = document.getElementById(id);
    el.textContent = message;
    el.style.display = 'block';
}
