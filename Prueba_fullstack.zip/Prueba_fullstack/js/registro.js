document.getElementById('registerForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const run = document.getElementById('run').value.trim();
    const fecha = document.getElementById('fechaNacimiento').value;
    const nombre = document.getElementById('nombre').value.trim();
    const apellidos = document.getElementById('apellidos').value.trim();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value.trim();
    const region = document.getElementById('region').value;
    const comuna = document.getElementById('comuna').value;
    const direccion = document.getElementById('direccion').value.trim();

    let valid = true;
    document.querySelectorAll('.error-message').forEach(el => el.style.display = 'none');

    // Validaciones
    if (!run) { showError('runError', 'El RUN es requerido'); valid = false; }
    else if (!/^\d{7,8}-[0-9kK]{1}$/.test(run)) { showError('runError', 'Formato RUN inválido'); valid = false; }

    if (fecha && new Date(fecha) > new Date()) { showError('fechaError', 'Fecha no puede ser futura'); valid = false; }

    if (!nombre) { showError('nombreError', 'Nombre requerido'); valid = false; }
    if (!apellidos) { showError('apellidosError', 'Apellidos requeridos'); valid = false; }

    const emailRegex = /^.+(@duoc\.cl|@profesor\.duoc\.cl|@gmail\.com)$/;
    if (!email) { showError('emailError', 'Correo requerido'); valid = false; }
    else if (!emailRegex.test(email)) { showError('emailError', 'Correo no permitido'); valid = false; }

    if (!password) { showError('passwordError', 'Contraseña requerida'); valid = false; }
    if (!direccion) { showError('direccionError', 'Dirección requerida'); valid = false; }

    if (!valid) return;

    // Guardar usuario en localStorage
    let usuarios = JSON.parse(localStorage.getItem('usuarios')) || [];
    const existe = usuarios.some(u => u.email === email);

    if (existe) {
        alert("Este correo ya está registrado.");
        return;
    }

    usuarios.push({
        run, fecha, nombre, apellidos, email, password, region, comuna, direccion
    });

    localStorage.setItem('usuarios', JSON.stringify(usuarios));
    alert('¡Registro exitoso! Ya puedes iniciar sesión.');
    window.location.href = 'login.html';
});

function showError(id, msg) {
    const el = document.getElementById(id);
    el.textContent = msg;
    el.style.display = 'block';
}
